<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container px-6 mx-auto grid">
        
        <div class="p-2">
            <h1 class="display-6 text-center">Student Information</h1>
        </div>
        <div class="p-3 pt-6">
            <table class="table table-striped">
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                    <tr>
                        <th scope="row">Student Name</th>
                        <td><?php echo e($user->student_name); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Email</th>
                        <td><?php echo e($user->email); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Mobile Number</th>
                        <td><?php echo e($user->mobile_number); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Nationality</th>
                        <td><?php echo e($student->nationality); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Passport / IC Number</th>
                        <td><?php echo e($student->passport_number); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Date of Birth</th>
                        <td><?php echo e($student->date_of_birth); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Passport Issue Date</th>
                        <td><?php echo e($student->passport_issue_date); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Obtain Single Entry Visa From</th>
                        <td><?php echo e($student->obtain_single_entry_visa); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Applicant E-mail Id</th>
                        <td><?php echo e($student->applicant_email_id); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Sex</th>
                        <td><?php echo e($student->sex); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Applicant Permanent Add</th>
                        <td><?php echo e($student->applicant_permanent_add); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Applicant Postal Code</th>
                        <td><?php echo e($student->applicant_postal_code); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Country</th>
                        <td><?php echo e($student->country); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Resident Number</th>
                        <td><?php echo e($student->resident_number); ?></td>
                    </tr>


                    <tr>
                        <th scope="row">Programme</th>
                        <td><?php echo e($student->programme); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Subject</th>
                        <td><?php echo e($student->subject); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Applicant Name</th>
                        <td><?php echo e($student->applicant_name); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Passport Issued Place</th>
                        <td><?php echo e($student->passport_issued_place); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Passport Expiry Date</th>
                        <td><?php echo e($student->passport_expiry_date); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Applicant Mobile Number</th>
                        <td><?php echo e($student->applicant_mobile_number); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Staff/Agent E-mail Id</th>
                        <td><?php echo e($student->agent_email_id); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Marital Status</th>
                        <td><?php echo e($student->marital); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Applicant City</th>
                        <td><?php echo e($student->applicant_city); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Applicant State</th>
                        <td><?php echo e($student->applicant_state); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Mobile Number</th>
                        <td><?php echo e($student->mobile_number); ?></td>
                    </tr>


                    <tr>
                        <th scope="row">Correspondence Address</th>
                        <td><?php echo e($student->correspondence_address); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Postal Code</th>
                        <td><?php echo e($student->postal_code); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Country</th>
                        <td><?php echo e($student->country_2); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Resident Number</th>
                        <td><?php echo e($student->resident_number_2); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Father's Tel No</th>
                        <td><?php echo e($student->father_tel_no); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Mother's Name</th>
                        <td><?php echo e($student->mother_name); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Mother's Occupation</th>
                        <td><?php echo e($student->mother_occupation); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Guardian Tel No</th>
                        <td><?php echo e($student->guardian_tel_no); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Highest Qualification</th>
                        <td><?php echo e($student->highest_qualification); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Year Of Passing</th>
                        <td><?php echo e($student->year_of_passing); ?></td>
                    </tr>


                    <tr>
                        <th scope="row">City</th>
                        <td><?php echo e($student->city); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">State</th>
                        <td><?php echo e($student->state); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Mobile Number</th>
                        <td><?php echo e($student->mobile_number_2); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Father's Name</th>
                        <td><?php echo e($student->father_name); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Father's Occupation</th>
                        <td><?php echo e($student->father_occupation); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Mother Tel No</th>
                        <td><?php echo e($student->mother_tel_no); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Gurdian's Name</th>
                        <td><?php echo e($student->gurdian_name); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Gurdian's Occupation</th>
                        <td><?php echo e($student->gurdian_occupation); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Overall Grade</th>
                        <td><?php echo e($student->grade); ?></td>
                    </tr>


                    <tr>
                        <th scope="row">Applicant Name (as in Passport)</th>
                        <td><?php echo e($student->applicant_name_2); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Are you currently studying in any Malaysian University/College ?</th>
                        <td><?php echo e($student->study); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Passport / IC Number</th>
                        <td><?php echo e($student->passport_number_2); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Do you have Current Malaysian Visa Pass Active ?</th>
                        <td><?php echo e($student->visa_pass); ?></td>
                    </tr>
                        
                </tbody>
            
            </table>
        </div>

        <div class="row p-3 pt-6">
            <table class="table table-striped">
                <thead>
                    <tr>
                    <th scope="col" class="text-center">SI. NO.</th>
                    <th scope="col">Upload Document Example Link</th>
                    <th scope="col">Document Name</th>
                    <th scope="col">Upload Document</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row" class="text-center">1</th>
                        <td>Page Link</td>
                        <td>
                            <?php echo e($student->health_declaration); ?>

                        </td>
                        <td>
                            <a href="<?php echo e(asset('uploads/health')); ?>/<?php echo e($student->health_declaration_file); ?>" download><img src="<?php echo e(asset('uploads/health')); ?>/<?php echo e($student->health_declaration_file); ?>" alt="img" style="width: 70px; height: 60px" ></a>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row" class="text-center">2</th>
                        <td>Page Link</td>
                        <td>
                            <?php echo e($student->passport_scanned); ?>

                        </td>
                        <td>
                            <a href="<?php echo e(asset('uploads/passport')); ?>/<?php echo e($student->passport_scanned_file); ?>" download><img src="<?php echo e(asset('uploads/passport')); ?>/<?php echo e($student->passport_scanned_file); ?>" alt="img" style="width: 70px; height: 60px" ></a>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row" class="text-center">3</th>
                        <td>Page Link</td>
                        <td>
                            <?php echo e($student->photo); ?>

                        </td>
                        <td>
                            <a href="<?php echo e(asset('uploads/photo')); ?>/<?php echo e($student->photo_file); ?>" download><img src="<?php echo e(asset('uploads/photo')); ?>/<?php echo e($student->photo_file); ?>" alt="img" style="width: 70px; height: 60px" ></a>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row" class="text-center">4</th>
                        <td>Page Link</td>
                        <td>
                            <?php echo e($student->academic_certificate_1); ?>

                        </td>
                        <td>
                            <a href="<?php echo e(asset('uploads/certificates')); ?>/<?php echo e($student->academic_certificate_file_1); ?>" download><img src="<?php echo e(asset('uploads/certificates')); ?>/<?php echo e($student->academic_certificate_file_1); ?>" alt="img" style="width: 70px; height: 60px" ></a>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row" class="text-center">5</th>
                        <td>Page Link</td>
                        <td>
                            <?php echo e($student->academic_certificate_2); ?>

                        </td>
                        <td>
                            <a href="<?php echo e(asset('uploads/certificates')); ?>/<?php echo e($student->academic_certificate_file_2); ?>" download><img src="<?php echo e(asset('uploads/certificates')); ?>/<?php echo e($student->academic_certificate_file_2); ?>" alt="img" style="width: 70px; height: 60px" ></a>
                        </td>
                    </tr>
                    
                </tbody>
            </table>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        

        <div class="p-4 pt-6">
            <a href="<?php echo e(route('student.registration.edit',Auth::user()->id)); ?>">
                <button type="button" class="btn btn-info float-right">Edit</button>
            </a>
        </div>
    
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php /**PATH E:\xampp\htdocs\unice\resources\views/student/show.blade.php ENDPATH**/ ?>