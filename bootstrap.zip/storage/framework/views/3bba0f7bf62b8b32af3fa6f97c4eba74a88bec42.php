<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12 w-full">
        <div class="max-w-7x1 mx-auto sm:px-8 lg:px-10">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-5 bg-white border-b border-gray-200">

                <div class="flex justify-end p-2">
                  
                </div>
                
                <div class="overflow-x-auto relative shadow-md sm:rounded-lg">
                    <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400 table-auto">
                        <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                            <tr>
                                <th scope="col" class="py-3 px-1">
                                    SL
                                </th>

                                <th scope="col" class="py-2 px-1">
                                   Agency Name
                                </th>
                                 <th scope="col" class="py-2 px-1">
                                    Email
                                </th>
                                  <th scope="col" class="py-2 px-1">
                                    Agency Id
                                </th>
                                 <th scope="col" class="py-2 px-1">
                                   Mobile Number
                                </th>
                                 <th scope="col" class="py-2 px-1">
                                   Status
                                </th>
                                <th scope="col" class="py-2 px-1">
                                    Action
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $all_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="bg-white border-b dark:bg-gray-900 dark:border-gray-700">
                                    <td class="py-4 px-6 font-medium"><?php echo e($k+1); ?></td>
                                    <th scope="row" class="py-4 px-1 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                        <?php echo e($val->agency_name); ?>

                                    </th>
                                    <td class=""><?php echo e($val->email); ?></td>
                                     <td class=""><?php echo e($val->generated_id ?? 'N/A'); ?></td>
                                    <td class=""><?php echo e($val->mobile_number); ?></td>
                                    <td class="">   <?php if($val->status == 1): ?>
                                        <span class="badge badge-pill badge-success"> Active </span>
                                        <?php else: ?>
                                       <span class="badge badge-pill badge-danger"> InActive </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-4 px-6">
                                        <div class="flex space-x-2">
                                             <a href="<?php echo e(route('admin.agency.details',$val->id)); ?>" class="px-4 py-2 bg-green-500 hover:bg-blue-700 text-white rounded-md"><i></i>View</a>
                                            <a href="#" class="px-4 py-2 bg-blue-500 hover:bg-blue-700 text-white rounded-md"><i></i>Edit</a>
                                             <a href="#" class="px-4 py-2 bg-red-500 hover:bg-blue-700 text-white rounded-md"><i></i>Delete</a>

                                             <?php if($val->status == 1): ?>
                                             <a href="#" class="btn btn-danger" title="Inactive Now"><i class="fa fa-arrow-down"></i>Inactive </a>
                                                 <?php else: ?>
                                             <a href="#" class="btn btn-success" title="Active Now"><i class="fa fa-arrow-up"></i>Active </a>
                                                 <?php endif; ?>
                                        
                                            
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="pagination">
                        <?php echo e($all_data->links()); ?>

                        
                    </div>
                </div>


                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php /**PATH E:\xampp\htdocs\unice\resources\views/admin/agency/index.blade.php ENDPATH**/ ?>