<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Unice</title>
       <!-- Horizontal Stepper -->
            <link rel="stylesheet" href="{{ asset('assets/css/style.bundle.css') }}">
            <script src="{{ asset('assets/js/scripts.bundle.js') }}"></script>
            
            <!-- Bootstrap CDN Links -->
            <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
            <script src="{{ asset('assets/js/bootstrap.bundle.min.js') }}"></script>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <!-- Styles -->
        

        <style>
            body {
                font-family: 'Nunito', sans-serif;
            }
        </style>
    </head>
    <body class="antialiased">
         <div class="relative flex items-top justify-center min-h-screen bg-gray-100 dark:bg-gray-900 sm:items-center py-4 sm:pt-0">
           <nav class="navbar navbar-dark navbar-expand-sm bg-dark fixed-top">
                <div class="container">
                <a href="/" class="navbar-brand">
                <i class="fas fa-blog"></i> &nbsp;
                <img src="{{ asset('assets/img/Unice_Education_Logo.jpg') }}" width="100px">
                </a>

                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>


                <div id="navbarCollapse" class="collapse navbar-collapse">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a href="" class="nav-link active">
                            Home
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="" class="nav-link active">
                            Blog
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="" class="nav-link active">
                            About
                        </a>
                    </li>
                     @if (Route::has('login'))
                      @auth
                    <li class="nav-item">
                        <a href="{{ url('/dashboard') }}" class="nav-link active">
                           Dashboard
                        </a>
                    </li>
                     @else
                      <li class="nav-item">
                        <a href="{{ route('login') }}" class="nav-link active">
                           Log in
                        </a>
                       
                    </li>

                         @if (Route::has('register'))
                          <li class="nav-item">
                            <a href="{{ route('student') }}" class="nav-link">Register</a>
                            </li>
                        @endif
                     @endauth
                     @endif
                </ul>
                </div>



            </div>
        </nav>
            
          </div>
         <div class="container">
            <div class="row">
                <div class="col-10 offset-md-1">
                    <div class="card" style="margin-top: 100px;">
                        <div class="card-header py-4">
                            <h3>Application Status</h3>
                        </div>
                        <div class="card-body">
                            <div class="status-border">
                                <div class="row">

                                    <div class="col-md-4">
                                        
                                    </div>
                                    <div class="col-md-8">
                                        <h3>Summary</h3>
                                        <hr>
                                        <h5>Full Name: Hasan Imtiaz</h5>
                                        <h5>Student Id: ST0012</h5>
                                        <h5>Application Number: 12</h5>
                                        <h5>Application Type: New</h5>
                                        <h5>Application Status: EMGS Approval Letter</h5>

                                        <p>As per the announcement from the Malaysian Government on the transition to the endemic phase on 1 April 2022, the Travel Authorisation Letter is no longer part of the requirements for International Students to enter Malaysia.</p>
                                        
                                    </div>
                                    
                                </div>
                                
                            </div>
                            
                        </div>
                       
                        
                    </div>

                    <div class="card" style="margin-top: 100px;">
                        <div class="card-header py-4">
                          
                        </div>
                        <div class="card-body">
                            <div class="status-border">
                                <div class="row">

                                    <div class="col-md-7">
                                        
                                    </div>
                                    <div class="col-md-5">
                                        <h3>Summary</h3>
                                        <hr>
                                        <h5>Full Name: Hasan Imtiaz</h5>
                                        <h5>Student Id: ST0012</h5>
                                        <h5>Application Number: 12</h5>
                                        <h5>Application Type: New</h5>
                                        <h5>Application Status: EMGS Approval Letter</h5>

                                        <p>As per the announcement from the Malaysian Government on the transition to the endemic phase on 1 April 2022, the Travel Authorisation Letter is no longer part of the requirements for International Students to enter Malaysia.</p>
                                        
                                    </div>
                                    
                                </div>
                                
                            </div>
                            
                        </div>
                       
                        
                    </div>
                   
                    
                </div>
                
            </div>
             
         </div>

         <style type="text/css">
             
             .navbar .navbar-brand {
                  font-size: 30px;
                }
                .navbar .nav-item {
                  padding: 10px 20px;
                }
                .navbar .nav-link {
                  font-size: 20px;
                  margin-left: 10px;
                }
                .fa-bars {
                  color: #007bff;
                  font-size: 30px;
                }
                .status-border {
                border: #f9a51c solid 1px;
                border-radius: 5px;
                padding: 5px;
                width: 100%;
                float: left;
                margin-top: 10px;
             }
         </style>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
         <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    </body>
</html>
